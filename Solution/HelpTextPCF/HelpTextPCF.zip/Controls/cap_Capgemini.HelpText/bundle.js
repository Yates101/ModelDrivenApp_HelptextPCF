/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./HelpText/index.ts":
/*!***************************!*\
  !*** ./HelpText/index.ts ***!
  \***************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.HelpText = void 0;\nvar HelpText = /** @class */function () {\n  function HelpText() {}\n  HelpText.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n    // Control initialization code\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    this._notifyOutputChanged = notifyOutputChanged;\n    // Used to make the content of the PCF dynamic, based on the resizing of the container\n    context.mode.trackContainerResize(true);\n    // Add event listener to the window to pick up the return message of the event listeners added to fields and pass to the event handler function\n    window.addEventListener('onSelectField', function (event) {\n      var message = event.detail;\n      console.log(message, 'message recieved by PCF');\n      _this.formFieldSelected(message.Field);\n    });\n    // Add event listeners to the form fields to register the selection\n    // Only generated form field container divs have this tag\n    var formFields = document.querySelectorAll(\"div[data-control-name]\");\n    // Create custome event that will be registered by PCF's event listener\n    formFields.forEach(function (div) {\n      console.log(div, 'div found');\n      div.addEventListener(\"click\", function () {\n        console.log('clicked', div);\n        var event = new CustomEvent(\"onSelectField\", {\n          detail: {\n            Field: div.getAttribute(\"data-control-name\")\n          }\n        });\n        window.dispatchEvent(event);\n      });\n    });\n    // Assign placeholder text\n    var placeHolderHeader = \"\";\n    var placeHolderText = \"\";\n    if (context.parameters.PlaceHolderHeader.raw != null) {\n      placeHolderHeader = placeHolderHeader + context.parameters.PlaceHolderHeader.raw;\n    } else {\n      placeHolderHeader = placeHolderHeader + \"Help Text\";\n    }\n    if (context.parameters.PlaceHolderText.raw != null) {\n      placeHolderText = placeHolderText + context.parameters.PlaceHolderText.raw;\n    } else {\n      placeHolderText = placeHolderText + \"Please select a field to display the related help text below.\";\n    }\n    // Create HTML elements (with classes for css styling)\n    this.helpTextHeader = document.createElement(\"h1\");\n    this.helpText = document.createElement(\"p\");\n    // Combine text and elements and append to the container\n    this.helpTextHeader.innerText = placeHolderHeader;\n    this.helpText.innerText = placeHolderText;\n    container.appendChild(this.helpTextHeader);\n    container.appendChild(this.helpText);\n  };\n  HelpText.prototype.formFieldSelected = function (fieldName) {\n    console.log('formFielSelected triggered', fieldName);\n    this.helpTextHeader.innerText = fieldName;\n    this.helpText.innerText = \"\".concat(fieldName, \" related helptext\");\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  HelpText.prototype.updateView = function (context) {\n    var width = parseInt(context.mode.allocatedWidth.toString());\n    var height = parseInt(context.mode.allocatedHeight.toString());\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  HelpText.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  HelpText.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return HelpText;\n}();\nexports.HelpText = HelpText;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./HelpText/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./HelpText/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Capgemini.HelpText', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HelpText);
} else {
	var Capgemini = Capgemini || {};
	Capgemini.HelpText = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HelpText;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}